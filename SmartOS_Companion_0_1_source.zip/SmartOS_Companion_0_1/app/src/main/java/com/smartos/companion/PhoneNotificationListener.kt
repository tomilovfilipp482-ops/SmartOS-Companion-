package com.smartos.companion

import android.app.Notification
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.io.File
import java.io.FileOutputStream

class PhoneNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val extras = n.extras ?: Bundle()
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = sequenceOf(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
        ).filterNotNull().firstOrNull { it.isNotBlank() }.orEmpty()

        // Ignore notifications with no useful visible content, but preserve image-only alerts.
        val bitmap = extractPicture(n)
        val imagePath = bitmap?.let { savePreview(it, sbn.postTime) }
        if (title.isBlank() && text.isBlank() && imagePath == null) return

        val appLabel = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)

        NotificationStore.add(
            applicationContext,
            Notice(sbn.key.hashCode().toLong(), appLabel, title, text, sbn.postTime, imagePath)
        )
    }

    private fun extractPicture(notification: Notification): Bitmap? {
        val extras = notification.extras ?: return null
        // BigPictureStyle is the standard Android route for an image in a notification.
        (extras.get(Notification.EXTRA_PICTURE) as? Bitmap)?.let { return it }
        if (Build.VERSION.SDK_INT >= 31) {
            val icon = extras.getParcelable<android.graphics.drawable.Icon>(Notification.EXTRA_PICTURE_ICON)
            if (icon != null) {
                runCatching {
                    val drawable = icon.loadDrawable(this) ?: return@runCatching null
                    val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: 512
                    val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: 512
                    return drawableToBitmap(drawable, w.coerceAtMost(1024), h.coerceAtMost(1024))
                }.getOrNull()?.let { return it }
            }
        }
        return null
    }

    private fun drawableToBitmap(d: android.graphics.drawable.Drawable, width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        d.setBounds(0, 0, width, height)
        d.draw(canvas)
        return bitmap
    }

    private fun savePreview(source: Bitmap, timestamp: Long): String? = runCatching {
        val maxSide = 512
        val scale = minOf(1f, maxSide.toFloat() / maxOf(source.width, source.height))
        val preview = Bitmap.createScaledBitmap(
            source, (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1), true
        )
        val dir = File(filesDir, "notification_images").apply { mkdirs() }
        val file = File(dir, "notice_$timestamp.jpg")
        FileOutputStream(file).use { preview.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        file.absolutePath
    }.getOrNull()
}
