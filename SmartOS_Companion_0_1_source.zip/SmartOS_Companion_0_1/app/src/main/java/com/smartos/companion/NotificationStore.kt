package com.smartos.companion

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Notice(
    val id: Long,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val imagePath: String? = null
)

object NotificationStore {
    private const val PREFS = "smartos_notifications"
    private const val KEY = "items"

    @Synchronized
    fun add(context: Context, notice: Notice) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        val item = JSONObject().apply {
            put("id", notice.id); put("app", notice.app); put("title", notice.title)
            put("text", notice.text); put("time", notice.time)
            put("imagePath", notice.imagePath ?: JSONObject.NULL)
        }
        arr.put(item)
        // Keep the latest 150 notifications to avoid unlimited storage growth.
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 150) until arr.length()) trimmed.put(arr.getJSONObject(i))
        prefs.edit().putString(KEY, trimmed.toString()).apply()
    }

    fun read(context: Context): List<Notice> {
        val arr = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val o = arr.getJSONObject(i)
                Notice(o.getLong("id"), o.getString("app"), o.optString("title"),
                    o.optString("text"), o.getLong("time"),
                    if (o.isNull("imagePath")) null else o.getString("imagePath"))
            }.getOrNull()
        }.reversed()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
