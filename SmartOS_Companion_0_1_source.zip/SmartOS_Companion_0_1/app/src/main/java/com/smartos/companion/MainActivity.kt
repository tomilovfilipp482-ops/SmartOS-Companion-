package com.smartos.companion

import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var refresh by remember { mutableIntStateOf(0) }
                val notices = remember(refresh) { NotificationStore.read(this) }
                Scaffold(topBar = {
                    TopAppBar(title = { Text("SmartOS Companion") })
                }) { padding ->
                    Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
                        Text("Honor X9e Pro • этап 0.1", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("Сбор уведомлений телефона. Данные остаются на устройстве.")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text("Разрешить доступ к уведомлениям")
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) {
                            Text("Обновить список")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Уведомления: ${notices.size}")
                            TextButton(onClick = { NotificationStore.clear(this@MainActivity); refresh++ }) {
                                Text("Очистить")
                            }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(notices) { item ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(item.app, style = MaterialTheme.typography.labelMedium)
                                        if (item.title.isNotBlank()) Text(item.title, style = MaterialTheme.typography.titleSmall)
                                        if (item.text.isNotBlank()) Text(item.text)
                                        if (item.imagePath != null) {
                                            Text("📷 Фото получено и сохранено на телефоне", color = MaterialTheme.colorScheme.primary)
                                        }
                                        Text(DateFormat.getTimeInstance().format(Date(item.time)),
                                            style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
